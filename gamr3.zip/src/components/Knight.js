

const Knight = () => {
    return(
        <span>♘</span>
    );
}
export default Knight;