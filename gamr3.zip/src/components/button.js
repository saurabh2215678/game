import { ReactSVG } from 'react-svg';
import btnBg from '../assets/images/btn-bg.svg';

const Button = ({children, ...props}) => {
    return(
        <>
            <button {...props}>
                <ReactSVG src={btnBg} className='btn_bg'/>
                <span>{children}</span>
            </button>
        </>
    )
}
export default Button;