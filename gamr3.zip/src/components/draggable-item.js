import React from "react";
const DraggableItem = ({answer}) => {
    return(
        <li>{answer}</li>
    );
}
export default DraggableItem;