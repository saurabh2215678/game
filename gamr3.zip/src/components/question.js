import React, { useEffect, useRef, useState } from "react";
import Countdown from 'react-countdown';
import logoImg from '../assets/images/logo.png';
import {CircularProgressbar,buildStyles} from "react-circular-progressbar";
import "react-circular-progressbar/dist/styles.css";
import Button from "./button";
import { motion } from "framer-motion";

function shuffle(array) {
    let currentIndex = array.length,  randomIndex;
    while (currentIndex != 0) {
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex--;
      [array[currentIndex], array[randomIndex]] = [
        array[randomIndex], array[currentIndex]];
    }
    return array;
  }

function secondsToArray(sec){
    var secondsArray = [];
    for(let percentage = sec; percentage >= 0; ){
        var percentageValue = percentage * 100 / sec
        secondsArray.push(percentageValue);
        percentage--
    }
    return secondsArray;
}

function getPositionAtCenter(element) {
    const {top, left, width, height} = element.getBoundingClientRect();
    return {
        x: left + width / 2,
        y: top + height / 2
    };
}

function getDistanceBetweenElements(a, b) {
    const aPosition = getPositionAtCenter(a);
    const bPosition = getPositionAtCenter(b);

    return Math.hypot(aPosition.x - bPosition.x, aPosition.y - bPosition.y);  
}

const Questions = ({
    data, 
    setResults, 
    results, 
    setquestionIndex, 
    questionIndex,
    lavel
}) => {

    const [answerMarked, setAnswerMarked] = useState(null);
    const [time, setTime] = useState();
    const countdownRef = useRef();
    const constraintsRef = useRef(null);
    const fillBlanksRefs = useRef({});
    const dragElementRefs = useRef({});

    let draggingItemIndex;
    
    useEffect(()=>{
        var nowDate = Date.now() + (data['time-remaining'] * 1000)
        setTime(nowDate);        
    },[]);

    useEffect(()=>{
        setTime(Date.now() + (data['time-remaining'] * 1000));
        countdownRef?.current?.start();
    },[data]);

const handleNext = () => {
    data.passed = true;
    data.lavel = lavel;
    if(data.type == "true-false"){
        data['user-answer'] = answerMarked;
        data['user-answer-is'] = answerMarked == data['correct-answer']  ? 'correct' :
                                 answerMarked != null ? 'incorrect' : 'not attempted';
    }
    data['viewed-time'] = Date.now();
    const dataResult = results.find((result)=> result.id == data.id);
    if(!dataResult){
        setResults([...results, data]);
        setquestionIndex(questionIndex + 1);
    }
    setAnswerMarked(null);
}

const percentageValue = (i) => {
    return secondsToArray(data['time-remaining'])[i];
}

const handleDragStart = (event, info, index) => {
    draggingItemIndex = index;
    // console.log(index);
    // setDraggableIndex(`${index}`);
    // setHoldingElementId(index)
    // console.log('event', event);
    // console.log('info', info);
    // console.log('fillBlanksRefs', fillBlanksRefs.current);
    // console.log('dragElementRefs', dragElementRefs.current);
    
    // console.log(getDistanceBetweenElements(fillBlanksRefs.current[0], dragElementRefs.current[0]))
}

const handleDragTransitionEnd = (a) => {
    console.log(draggingItemIndex);
    console.log(getDistanceBetweenElements(fillBlanksRefs.current[0], dragElementRefs.current[0]))
}






    return(
        <div className="question_root">
            <div className="container">

                <div className="logo_wrapper">
                    <a href="#" className="logo">
                        <img src={logoImg} alt="" />
                    </a>
                </div>

                <div className="text-center">
                    <h3 className="font36 m-0">Level {lavel}</h3>
                    <h4 className="font52 fw700 color_theme">
                        {
                            data.type == "true-false" ? 'True & False' :
                            data.type == "fill-in-the-blanks" ? 'Fill in the blanks' : 'Match the Following'
                        }
                    </h4>
                    {time && <Countdown 
                        ref={countdownRef}
                        date={time} 
                        renderer={props => 
                            <div className="timer_wrapper">
                                <CircularProgressbar
                                    value={percentageValue(props.total / 1000)}
                                    styles={buildStyles({
                                    pathTransitionDuration: 0.15
                                    })}
                                />
                                <div className="couter-time">
                                    <span className="color_theme font20">{props.total / 1000}</span>
                                    <br/>Sec
                                </div>
                            </div>
                                
                            }
                        onComplete={handleNext}
                    />}
                    <h5 className="font23">Timer of <span className="fw600 color_theme font28">30 seconds</span> for True or False </h5>
                </div>
                
                <div className="box mt-4">
                    <div className="questionBox p-5">
                        {data.type == "true-false" &&
                        <>
                            <h3 className="text-center font28 color_theme">{data.question}</h3>
                            <div className="true-false">
                                <div onClick={()=>setAnswerMarked(true)} className={answerMarked == true ? 'active' : ''}>True</div>
                                <div onClick={()=>setAnswerMarked(false)} className={answerMarked == false ? 'active' : ''}>False</div>
                            </div>
                        </>}

                        {data.type == "fill-in-the-blanks" &&
                        <div className="fill-in-the-blanks" ref={constraintsRef}>
                            <ul>
                                {data.question.map((question, index)=> 
                                    <li key={index}>
                                        {question.split('_____')[0]}
                                        <div className="item_box" ref={ref => fillBlanksRefs.current[index] = ref}></div>
                                        {question.split('_____')[1]}
                                    </li>
                                )}
                            </ul>

                            <ul className="options">
                                {shuffle(data['correct-answer']).map((answer, index)=> 
                                    <motion.li 
                                    drag 
                                    ref={ref => dragElementRefs.current[index] = ref}
                                    dragConstraints={constraintsRef}
                                    dragTransition={{ bounceStiffness: 600, bounceDamping: 20 }}
                                    dragElastic={0.5}
                                    whileTap={{ cursor: "grabbing" }}
                                    onDragStart={(event, info)=>handleDragStart(event, info, index)}
                                    onDragTransitionEnd={handleDragTransitionEnd}
                                    key={index}
                                    >{answer}</motion.li>
                                )}
                            </ul>
                        </div>}
                    </div>
                </div>

                <div className="text-center my-4">
                    <Button onClick={handleNext} className="btn">Next</Button>
                </div>
            </div>
        </div>
    )
}
export default Questions;