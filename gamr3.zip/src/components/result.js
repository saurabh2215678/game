import React, { useEffect, useState } from "react";
import { ReactSVG } from 'react-svg';
import logoImg from '../assets/images/logo.png';
import looseSvg from '../assets/images/lose.svg';
import winSvg from '../assets/images/win.svg';
import Button from "./button";

const Result = ({results, setShowResult, completed}) => {

    const [passed, setPassed] = useState(false);
    var lastLabel = results[results.length - 1].lavel;
    var thisLavelResults = results.filter((item)=>item.lavel == lastLabel);
    var isCorrect = !thisLavelResults.find((item)=> item['user-answer-is'] != 'correct');

    useEffect(()=>{
        if(isCorrect){
            setPassed(true);
        }
    },[results]);
    
    return(
        <div className="result_root">
            <div className="container">
                <div className="logo_wrapper">
                    <a href="#" className="logo">
                        <img src={logoImg} alt="" />
                    </a>
                </div>
                <div className="result_box">
                        {passed ?
                        <>
                        <div className="text-center">
                            <ReactSVG src={winSvg} className='result_icon'/>
                            <h3 className="font30 color_theme mb-5">Wow! You are right.</h3>
                            <p className="font25">You truly understand the importance of accountability in healthcare.</p>
                        </div>
                        </> :
                        <>
                        <div className="text-center">
                            <ReactSVG src={looseSvg} className='result_icon'/>
                            <h3 className="font30 color_theme mb-5">Oops! you missed some.</h3>
                            <p className="font25">Here are the correct answers.</p>
                        </div>
                        <div className="box">
                            <div className="result-table">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Questions</th>
                                            <th>Answer</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            thisLavelResults.map((item, i)=> 
                                            <tr key={i}>
                                                <td>{item.question}</td>
                                                <td>{item["correct-answer"] ? 'true' : 'false'}</td>
                                            </tr>
                                            )
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        </>
                        }
                        
                </div>
                {completed ?
                <div className="text-center my-4"><Button onClick={()=>window.location.reload()} className="btn">Next</Button></div> :
                <div className="text-center my-4"><Button onClick={()=>setShowResult(false)} className="btn">Next</Button></div>
                // <button onClick={()=>setShowResult(false)}>Next</button>
                }

            </div>
        </div>
    )
}
export default Result;