const data = [
    {
        lavel: 1,
        questions: [
            {   'id' : 1,
                'time-remaining': 30,
                'passed' : false,
                'question' : '1 Patient-provider accountability is critical to improve the quality of health care services',
                'type' : 'true-false',
                'viewed-time': null, // timestamp when user open this question 
                'correct-answer' : true,
                'user-answer' : null,
                'user-answer-is' : 'not-attempted' // correct , incorrect, not attempted
            },
            {
                'id' : 2,
                'time-remaining': 45,
                'passed' : false,
                'question' : '2 Seeking patient feedback should be avoided for fear of getting nevigative comments',
                'type' : 'true-false',
                'viewed-time': null, // timestamp when user open this question 
                'correct-answer' : true,
                'user-answer' : null,
                'user-answer-is' : 'not-attempted' // correct , incorrect, not attempted
            },
            {
                'id' : 3,
                'time-remaining': 30,
                'passed' : false,
                'question' : '3 Patients and their families do not have any responsibility towards the health facility and healthcare provider',
                'type' : 'true-false',
                'viewed-time': null, // timestamp when user open this question 
                'correct-answer' : false,
                'user-answer' : null,
                'user-answer-is' : 'not-attempted' // correct , incorrect, not attempted
            }
        ]
    },
    {
        lavel: 2,
        questions: [
            {
                'id' : 4,
                'time-remaining': 30,
                'passed' : false,
                'question' : [
                            'Work-related stress is the adverse reaction people have to excessive _____ and demands placed on them at work.',
                            'Symptoms in staf such as fatigue, nitabilty, anxiety, aggression, lack of performance may indicate _____ stress.',
                            'Periodic recognition and rewards for high performing staf helps keep their _____ high.',
                            ],
                'type' : 'fill-in-the-blanks',
                'viewed-time': null, // timestamp when user open this question 
                'correct-answer' : ['Workplace', 'Motivation', 'Pressures'],
                'user-answer' : null,
                'user-answer-is' : 'not-attempted' // correct , incorrect, not attempted
            }
            
        ]
    }
];

export {data}